package za.co.entelect.challenge.entities

case class Position(x: Int,
                    y: Int)