package za.co.entelect.challenge.entities

case class Opponent(id: Int,
                    score: Int,
                    worms: List[EnemyWorm])