﻿using System.ComponentModel;

namespace StarterBot.Enums
{
    public enum CellType
    {
        DEEP_SPACE,
        AIR,
        DIRT,
    }
}
