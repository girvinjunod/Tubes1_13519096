package za.co.entelect.challenge.entities

case class Weapon(damage: Int,
                  range: Int)
