﻿namespace StarterBot.Entities
{
    public class MapPosition
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}