package za.co.entelect.challenge.commands

trait Command {
  def render(): String
}
