# Reference Bot

The reference bot is built on top of the [starter-bots](https://github.com/EntelectChallenge/2019-Worms/tree/develop/starter-bots) 
and has the ability to play a game from start to finish with some cleverness built in. This is there to help contestants who want something a bit smarter to work from.

The reference bot was built using Javascript and has the same setup requirements as the Javascript starter-bot. 
These setup requirements can be found [here](https://github.com/EntelectChallenge/2019-Worms/tree/develop/starter-bots/javascript).