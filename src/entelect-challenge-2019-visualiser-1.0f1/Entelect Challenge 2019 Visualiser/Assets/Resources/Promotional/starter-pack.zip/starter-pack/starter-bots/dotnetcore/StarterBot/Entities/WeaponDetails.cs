﻿namespace StarterBot.Entities
{
    public class WeaponDetails
    {
        public int Damage { get; set; }
        public int Range { get; set; }
    }
}
